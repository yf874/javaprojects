package cs102_projects;

import java.util.ArrayList;
import java.util.Collections;



/**
 * This class is a container class just like the ArrayList<E> class that is part of JavaAPI.
 * The main difference is that this class will be used for working with generic elements 
 * whose type implements Comparable<E> interface. 
 * this class will be using a bounded generic type
 * 
 * @author AlecFu (YufeiFu)
 *
 * @version 09/26/2016
 */
public class MyArrayList <E extends Comparable<E>> extends ArrayList<E> 
{
	
	/**
	 * The default constructor that inherit from the super class
	 * creating an array list
	 */
	public MyArrayList()
	{
		super();
	}
	
	/**
	 * This method sort this MyArraylist using the method under collections.
	 * Sort by natural order
	 */
	public void sort()
	{
		Collections.sort(this);
	}
	
	/**
	 * This method checks whether an MyArrayList is sorted  or not
	 * by checking whether each next object is greater than the previous one.
	 * 
	 * @return Check if all the elements in the MyArrayList is sorted, if so,
	 * return true. False otherwise. 
	 */
	public boolean isSorted()
	{
		//looping through the MyArrayList
		for (int i=0;i<this.size();i++)
		{
			//check if each next object is greater than previous one
			if (this.get(i).compareTo(this.get(i+1))>0)
			{
				return false;
			}
		}
		return true;
	}
	
	/**
	 * This method override the contains method in the ArrayList class
	 * The method would determine if the elements stored in the container are sorted, 
	 * if so, apply a binary search algorithm in the Collections. 
	 * If the elements are not in a sorted order, 
	 * the method should call the contains implemented in the ArrayList class 
	 * (this method performs a linear search).
	 * 
	 * @param n The object n, more specifically in this case, the name object to be tested
	 * 
	 * @return true if the name object could be found in the current MyAyyarList,
	 * false otherwise.
	 */
	@Override
	public boolean contains(Object n)
	{
		//Check whether the MyArrayList is already in the natural order
		if (this.isSorted()==true) 
		{
			//Perform a binary search to be more efficient
			if ((Collections.binarySearch(this, (E)n))>=0)
			{
				return true;
			}
			else 
			{
				return false;
			}
		}
		
		else 
		{
			//if the MyArrayList is not sorted, perform a linear search
			return this.contains(n);
		}
			
	}
		
}
