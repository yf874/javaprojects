package cs102_projects;

/**
 * This class is a container that stores all the Name object for a particular year
 * 
 * @author AlecFu (YufeisFu)
 * @version 09/26/2016
 *
 */

public class YearNames 
{
	private int year;
	
	MyArrayList<Name> yearnames;
	
	
	/**
	 * The constructor of the YearNames object
	 * 
	 * @param year the particular year for baby names 
	 */
	public YearNames (int year)
	{
		//Set the input year to the data field
		this.year=year;
		//create a corresponding MyArrayList to store name object
		yearnames= new MyArrayList<Name>();
	}
	
	
	/**
	 * Append a new name object to the MyarrayList that holds Baby Name object for a certain year
	 * 
	 * @param n The name object to be added 
	 * 
	 * @throws IllegalArgumentException if the MyArrayList yearnames, 
	 * which contain all the name object for certain year,already have this name object.
	 */
	public void add(Name n) throws IllegalArgumentException 
	{
		//check if the MyArrayList already have the name object n
		if (yearnames.contains(n)) 
		{
			throw new IllegalArgumentException();
		}
		//add the name object n to the MyArrayList
		yearnames.add(n);
	}
	
	
	/**
	 *  returns the number of babies that were given the name specified by the parameter. 
	 *  If there are two Name objects matching the specified name string 
	 *  (one male, one female), the sum of two counts should be returned.
	 * 
	 * @param name the name user want to check 
	 * @return the integer number of babies who used name n in a certain year
	 */
	public int getCountByName (String name) 
	{
		int count=0;
		//Searching through the MyArrayList yearnames
		for (int i=0;i<yearnames.size();i++) 
		{
			//see if input name is in the list
			if (yearnames.get(i).getName().equalsIgnoreCase(name)) 
			{	
				//get count of the name object that has data field name 
				//same as the specified parameter
				count+=yearnames.get(i).getCount();
			}	
		}
		return count;
	}
	
	/**
	 * This method will get the fraction of the number of babies using certain name
	 * divided by the total number of babies born in a certain year.
	 * 
	 * @param name The name user want to check the fraction for.
	 * 
	 * @return the double value of fraction: 
	 * (Number of babies with a given name)/(Total number of babies in that year )  
	 * for a certain name
	 */
	public double getFractionByName(String name) 
	{
		int total=0;
		// get the count of Name specified in the parameter 
		for (int i=0;i<yearnames.size();i++) 
		{
			total+=yearnames.get(i).getCount();
		}
		
		int count=getCountByName(name);
		// get the fraction of by dividing the count by the total number of babies in that year
		double fraction=count/(double)total;
		return fraction;
	}
	
	/**
	 * The toString method that is overridden to print the year message of
	 * the YearName object
	 * 
	 * @return string representation of the object with the year.
	 */
	@Override
	public String toString() 
	{
		return "Baby names in "+year+" are stored";	
	}
	

}
