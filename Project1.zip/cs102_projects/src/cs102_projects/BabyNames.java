package cs102_projects;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JOptionPane;

/**
 * This class is the main class of this project, contains main method.
 * This class is responsible for opening and reading the data files, 
 * obtaining user input, performing data validation 
 * and handing all errors that may occur 
 * 
 * @author AlecFu (YufeiFu)
 * 
 * @version 09/26/2016
 */
public class BabyNames {

	public static void main(String[] args) 
	{
		/*Create a list that contains all the yearNames object and all data.
		 * 136 indicates the number of YearNames(or file of years to be stored)
		 */
		YearNames[] alldata = new YearNames[136];
		
		//looping through the largest list to get to each YearNames object
		for (int i=0;i<alldata.length;i++) 
		{
			//Create a new file reference for each year's data file 
			String filename="data/yob"+(i+1880)+".txt";
			File f=new File (filename);
			
			//check if the data file could be read, if not print out error message
			if (!f.canRead()) 
			{
				System.err.printf("Error: cannot read"+"data from file %s",filename);
				System.exit(1);
			}
			
			//use a Scanner to scan file. 
			Scanner inputFile=null;
			try 
			{
				inputFile=new Scanner (f);
			}
			
			//Catch exception if the data file could not be read.
			catch (FileNotFoundException e) 
			{
				System.err.printf("Error: cannot read"+"data from file %s",filename);
				System.exit(1);
			}
			
			//if the file could be read, create a YearNames object that store all Name object for that year.
			YearNames yearName=new YearNames(i+1880);
	
			//go through the file to store information 
			while(inputFile.hasNextLine())
			{
				//split each line into a temp string list to separate data.  
				String[] tmp=inputFile.nextLine().split(",");
				
				//try to put different parameter information into corresponding Name object
				try 
				{
					
				Name n=new Name(tmp[0],tmp[1],Integer.parseInt(tmp[2]));
				//yearName.yearnames.sort();
				yearName.yearnames.add(n);

				}
				
				//if any of the parameter is not valid, catch exception and print err message
				catch (IllegalArgumentException e) 
				{
					System.err.println("The parameter is invalid.");
				}
			}

			inputFile.close();
			
			//Put the YearNames object into the corresponding position in the alldata list. 
			alldata[i]=yearName;
			//print out yearName object to when each years data is stored
			System.out.println(yearName);
		}
		
			boolean status=true;
			//set a user control while loop which kept prompting the input box until user plug in "q"
			while (status) 
			{
				String inputname=JOptionPane.showInputDialog(null, "What name would you like to search: ");
				if (inputname==null) {
					break;
				}
				else 
				{
					//if user enters "q" ignore case, while loop will break 
					if (inputname.equalsIgnoreCase("q") )
					{
						System.out.println("Thank you!");
						break;
					}
					
					else 
					{
						//Set a boolean variable shows whether a name exist or not in a certain year and all data set
						boolean exist=false;
						
						//looping through data set to search for tested name
						for (int k=0;k<alldata.length;k++) 
						{
							for (int z=0;z<alldata[k].yearnames.size();z++)
							{
								//if certain name is found
								if (alldata[k].yearnames.get(z).getName().compareToIgnoreCase(inputname)==0)
								{
									//get the fraction of the name in that year 
									double fraction=alldata[k].getFractionByName(inputname);
									//print histogram of that year
									printhist(fraction*100,k+1880);
									//change the boolean variable to be true
									exist=true;		
								}
								
							}
							
						}
					
						//if the name does not exist in any of the year, print out the message that the name does'n exist
						if (exist==false) 
						{
							System.out.println("No such name in the dataset.");
						}
					
					}
				}
			}
	}

	/**
	 * This method print out the histogram of the fraction of 
	 * a certain name used in a particular year by getting its fraction and year.
	 * 
	 * @param fraction The fraction of a specific baby name is been used in a certain year
	 * (number of babies used the name)/(total number of babies in that year)
	 * @param year The particular year to be tested 
	 */
	public static void printhist(double fraction,int year)
	{
		//get the number of bars in the histogram use the math ceiling function
		int num=(int)(Math.ceil(fraction*100));
		
		//print out the year, formatted fraction number and histogram bars
		System.out.printf(year+" (%.4f) "+":",fraction);
		while (num>0) 
		{
		System.out.print("|");
		num-=1;
		}
		System.out.println();
	}
}
	




