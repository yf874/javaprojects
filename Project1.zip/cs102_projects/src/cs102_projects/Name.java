package cs102_projects;


/**
 * This class stores information about a particular name for a particular year. 
 * It stores information about the name itself, the gender and the 
 * count (how many babies have been given that name).
 * 
 * @author AlecFu (YufeiFu)
 * @version 09/26/2016
 */
public class Name implements Comparable<Name>
{
	private String name,gender;
	private int count;
	
	
	/**
	 * The constructor of the Name object that contains information of name, gender and count.
	 * 
	 * @param name name of babies 
	 * @param gender gender of baby
	 * @param count the number of babies who use certain in a particular year
	 * @throws IllegalArgumentException if parameter name is null or
	 * parameter gender is not "f" or "m" ignore case or count is negative
	 */
	public Name (String name, String gender,int count) throws IllegalArgumentException
	{	
		//Check if there is a string name parameter specified
		if (name==null) 
		{
			throw new IllegalArgumentException();
		}
		
		//check if the gender parameter is valid
		if (!((gender.equalsIgnoreCase("f"))||gender.equalsIgnoreCase("m")))
		{
			throw new IllegalArgumentException();
		}
		//check if count is greater or equal to 0
		if (count<0) 
		{
			throw new IllegalArgumentException();
		}
		else
		{
	
		this.name=name;
		this.count=count;
		this.gender=gender;
		}
	}
	
	
	/**
	 * This method indicates whether the parameter specified object equals to this object
	 * 
	 * @param obj the reference object with which to compare.
	 * 
	 * @return true if this object is the same as the obj argument; false otherwise. 
	 */
	@Override

	public boolean equals(Object obj) 
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Name other = (Name) obj;
		if (count != other.count)
			return false;
		if (gender == null) 
		{
			if (other.gender != null)
				return false;
		} 
		else if (!gender.equals(other.gender))
			return false;
		if (name == null) 
		{
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	/**
	 * This method is a getter method that get name of the Name Object
	 * 
	 * @return the name of this name object
	 */
	public String getName() 
	{
		return name;
	}
	
	/**
	 * This method is a getter method that get gender of the Name Object
	 * 
	 * @return the gender data field of this name object
	 */
	public String getGender()
	{
		return gender;
	}
	
	/**
	 * This method is a getter method that get count of the Name Object
	 * 
	 * @return the count, which is the number of babies use this name in a given year
	 */
	public int getCount()
	{
		return count;
	}

	/**
	 * This method compares the name object o with this object 
	 * and return integer value for the comparison.
	 * The comparison should be done by the name as the primary key (using alphabetical order), 
	 * by the count as the secondary key 
	 * (i.e., when two objects that have the same value of name are compared, 
	 * the comparison should be performed by count) 
	 * and by the gender as the third key.
	 * 
	 * @param o the Name object to be compared
	 * 
	 * @return a negative integer, zero, or a positive integer 
	 * as this object is less than, equal to, or greater than the specified object 
	 * with the specified order.
	 * 
	 */
	@Override
	public int compareTo(Name o) 
	{
		//Compare String name with its natural order
		if (this.name.compareTo(((Name) o).getName())==0) 
		{
			//if name is equal, compare count
			if (this.count==((Name) o).getCount()) 
			{
				//if count is equal as well, compare gender
				return (this.gender.compareToIgnoreCase(((Name) o).getGender()));	
			}
			
			else 
			{ 	//if counts are not equal, return difference
				return (this.count-((Name) o).getCount());
			}
		}
		
		else 
		{	
			//if name are not equal,return difference
			return (this.name.compareTo(((Name) o).getName()));
		}
		
	}
	
	/**
	 * This method will return a string representation of the Name object 
	 * with its name, gender and count.
	 * 
	 * @return string representation of the Name object.
	 */
	@Override
	public String toString()
	{
		return ("The baby's profile:\nName: "+name+"\nGender: "+gender+"\nCount: "+count);
		
	}
	
	
	
}
